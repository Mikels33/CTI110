one=int(input())
two=int(input())
if two<one:
    print("Second integer can't be less than the first.")
else:
    while one<=two:
        print(one, end=' ')
        one+=5
    print()