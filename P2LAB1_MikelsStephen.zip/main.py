mileage=float(input())
cost=float(input())
val1mile=20/mileage
val2mile=75/mileage
val3mile=500/mileage
val1=val1mile*cost
val2=val2mile*cost
val3=val3mile*cost
print(f'{val1:.2f} {val2:.2f} {val3:.2f}')